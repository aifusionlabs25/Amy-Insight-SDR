# Insight SDR: Discovery Questions Framework

## PURPOSE
Structured discovery questions to uncover customer pain, qualify fit, and guide conversation toward Insight solutions.

**Philosophy:** Ask to understand before suggesting. Map business pain → IT gap → Insight solution.

---

## OPENING QUESTIONS (Rapport & Context)

### 1. Business Priority Uncovering
"What's your #1 strategic priority for 2026?"
- *Listen for:* Revenue growth, cost reduction, speed/agility, compliance, talent retention, customer experience

---

### 2. Technology Role
"How is technology enabling or limiting that priority?"
- *Listen for:* Specific gaps (infrastructure, security, speed, cost, talent)

---

### 3. Decision Authority
"Who else should I be talking to about this?"
- *Listen for:* Decision-maker names, approval process, timeline for decisions

---

## CURRENT STATE ASSESSMENT

### 4. Infrastructure Baseline
"What does your current IT infrastructure look like? On-premises, cloud, hybrid?"
- *Follow-up:* "How long have you been on this infrastructure? Any plans to modernize?"

---

### 5. Cloud Adoption
"Have you adopted cloud? Which platforms (AWS, Azure, Google Cloud)? What percentage of workloads?"
- *Follow-up:* "Is cloud adoption on your roadmap for 2026?"

---

### 6. Team & Talent
"How large is your IT team? Are you able to keep up with modernization demands?"
- *Listen for:* Staffing gaps, burnout, inability to hire skilled resources

---

### 7. Budget & Spend
"What percentage of your IT budget goes to managing legacy infrastructure vs. innovation?"
- *Follow-up:* "Do you have visibility into your cloud spending?"
- *Listen for:* Budget constraints, cloud cost surprises

---

## PAIN POINT DISCOVERY

### 8. Primary Pain Identifier
"What's your biggest operational IT challenge right now?"
- *Listen for:* Cost, security, modernization, compliance, talent, speed, reliability

---

### 9. Cost Pain
*If they mention cost:*
- "How much are you spending on IT annually?"
- "What percentage is going to legacy infrastructure maintenance?"
- "Have you experienced unexpected cloud cost spikes?"
- "Do you have visibility into cloud spend by department or application?"

---

### 10. Security & Compliance Pain
*If they mention security/compliance:*
- "What's your current security posture? Recent assessment or audit?"
- "Have you experienced a security incident? Any regulatory audit findings?"
- "What compliance frameworks apply to your organization (HIPAA, SOC 2, FedRAMP, GDPR)?"
- "Are you evaluating zero-trust architecture?"

---

### 11. Modernization Pain
*If they mention aging infrastructure:*
- "What's driving your modernization need? Business requirements or technical debt?"
- "How old is your core infrastructure? Servers, networks, databases?"
- "Have you evaluated cloud migration? What are the barriers?"
- "What's your data center refresh or sunsetting timeline?"

---

### 12. Talent & Retention Pain
*If they mention staff challenges:*
- "Are you able to hire skilled IT talent? What's the market like in your region?"
- "Is employee experience a priority for you?"
- "How are you addressing work-from-home or hybrid work needs?"

---

### 13. Digital Transformation Pain
*If they mention business agility/innovation:*
- "How quickly can you bring new applications to market? Months? Weeks?"
- "What's limiting your digital innovation? Technical debt, budget, skills?"
- "Are you falling behind competitors in digital capabilities?"

---

## SOLUTION FIT ASSESSMENT

### 14. AI/GenAI Readiness
"Have you explored artificial intelligence or generative AI for your business?"
- "What use cases are you considering? (customer service, content generation, process automation)"
- "Are you concerned about data security in AI implementation?"
- "Have you done an AI readiness assessment?"

---

### 15. Cloud Optimization
"If you're in cloud, are you satisfied with your cloud costs? Any optimization opportunities?"
- "Do you have a FinOps framework or cost governance process?"
- "What percentage of your cloud resources are idle or overprovisioned?"

---

### 16. Vendor Strategy
"Are you open to external partnerships for modernization? Or do you prefer to build internally?"
- *Listen for:* Openness to vendors, previous vendor relationships, preferences for large vs. specialized firms

---

### 17. Partner History
"Have you worked with consulting partners before? What worked well? What didn't?"
- *Listen for:* Partner satisfaction, previous implementation experience, lessons learned

---

## URGENCY & TIMELINE

### 18. Timeline Urgency
"When would you want to address this [identified pain point]?"
- *Listen for:* Q1/Q2 (urgent), H2 (planned), next year (exploratory)

---

### 19. Budget Cycle
"Do you have budget allocated for IT modernization in 2026?"
- *Listen for:* Approved, pending, under consideration

---

### 20. Competitive Trigger
"Are you seeing competitors move ahead in [cloud/AI/digital]? Any market pressure to modernize?"
- *Listen for:* Competitive threat, market shift, customer feedback

---

## QUALIFICATION (BANT Framework)

### B — Budget
- "Is there budget allocated for this initiative?"
- "What's the expected investment range?" ($50K–$500K+)
- "Is this capex or opex?"

---

### A — Authority
- "Who makes the final decision on IT investments like this?"
- "Who are the key stakeholders that need to be involved?"
- "What's the approval process and timeline?"

---

### N — Need
- "How urgent is this? Business-critical or nice-to-have?"
- "What's the business impact if you don't address this?"
- "Have you quantified the cost of the current situation?"

---

### T — Timeline
- "When do you need to have this resolved?"
- "When would you want to start a project like this?"
- "What's driving the timeline?"

---

## INSIGHT-SPECIFIC QUESTIONS

### 21. Solutions Integrator Fit
"Have you worked with a solutions integrator before (vs. single-vendor approach)?"
- *Listen for:* Openness to vendor-agnostic approach

---

### 22. Managed Services Interest
"Are you interested in shifting IT operations to a managed services model? (24/7 support, ongoing optimization)"
- *Listen for:* Appetite for operational model change

---

### 23. Adoption & Change Management
"How important is change management and user adoption in your transformations?"
- *Listen for:* Willingness to invest in change management (Prosci methodology)

---

### 24. Industry-Specific Requirements
*For Public Sector:*
"Are you aware of procurement frameworks like GSA, SEWP, CIO-NS? Would you benefit from having those options?"

*For Healthcare:*
"What's your HIPAA compliance readiness? Any audit findings?"

*For Financial Services:*
"What's your approach to AI governance? Data privacy concerns in GenAI implementation?"

---

## CLOSING QUESTIONS

### 25. Next Steps Receptivity
"Based on our conversation, would it be valuable to dive deeper with a technical specialist?"
- *Alternative:* "Would you be open to a brief technical assessment to understand your modernization options?"

---

### 26. Contact Expansion
"In addition to your perspective, who else should I connect with? (CTO, CFO, business unit leader)"
- *Listen for:* Willingness to introduce stakeholders

---

### 27. Information Needs
"What information would be most helpful to you as you evaluate modernization options?"
- *Listen for:* Case studies, ROI calculators, technical whitepapers, etc.

---

## DISCOVERY CONVERSATION FLOW

### Framework: Problem → Impact → Solution → Next Step
