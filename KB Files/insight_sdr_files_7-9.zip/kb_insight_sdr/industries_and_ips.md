# Insight SDR: Industries & Verticals + IPS Reference

## PURPOSE
Industry vertical context, pain points, solutions, and Insight Public Sector (IPS) routing guidance.

---

## INDUSTRY 1: HEALTHCARE

### Market Context
- **AI Market Growth:** $11.6B by 2026 (healthcare AI specifically)
- **Digital Transformation:** Mandate across healthcare systems (EHR modernization, interoperability)
- **Primary Drivers:** Patient outcomes, provider burnout, cost control, compliance

### Pain Points
1. **EHR Fragmentation** — Multiple EHR systems not talking to each other; data silos
2. **Patient Data Security & HIPAA** — HIPAA compliance burden, breach risk, regulatory audits
3. **Imaging Backlogs** — Radiologists overwhelmed; patient wait times extending
4. **Interoperability Challenges** — Data exchange between healthcare providers difficult
5. **Provider Burnout** — Administrative burden, documentation overload
6. **Telehealth Infrastructure** — Post-COVID, need robust telehealth platforms

### Insight Solutions
- **HIPAA-Secure Cloud:** Healthcare-compliant infrastructure
- **AI Diagnostics:** AI-powered imaging analysis (assist radiologists)
- **EHR Integration:** Connect fragmented EHR systems
- **Telehealth Infrastructure:** Secure, scalable telehealth platforms
- **Healthcare Data Security:** HIPAA-compliant security architecture
- **Health Data Analytics:** AI-driven patient outcome prediction

### Proof Points
- Healthcare provider: Zero-breach deployment with Insight security hardening
- 1,000+ devices deployed for telehealth (rapid deployment capability)
- AI imaging analysis: Accelerating radiologist review process

### Discovery Questions
1. "What's your current EHR situation? Single system or multiple?"
2. "Have you had a HIPAA audit? Any findings?"
3. "What's your biggest pain point—workflow efficiency, security, or patient outcomes?"
4. "Are you exploring AI for clinical decision support or diagnostics?"
5. "Do you need to modernize infrastructure while maintaining HIPAA compliance?"

### Qualification Signals
✅ **Highly Qualified:** Recent HIPAA audit, budget approved, CISO or Chief Medical Information Officer involved  
⏳ **Moderately Qualified:** Exploring modernization, budget TBD, CTO/IT director only  
🔄 **Nurture:** Exploratory phase, no immediate budget

### Special Routing
- **IPS Route:** If healthcare provider is part of government system (VA, state hospital, etc.)
- **Vertical Specialist:** Healthcare vertical specialist available for technical conversations

---

## INDUSTRY 2: RETAIL & E-COMMERCE

### Market Context
- **Omnichannel Shift:** Retail moving to unified online/offline experience
- **Millennial Expectations:** Younger customers expect digital-first, personalized experience
- **GenAI Adoption:** AI-powered customer engagement (chatbots, personalization, inventory)
- **Cloud-First Infrastructure:** Store systems and e-commerce platforms increasingly cloud-based

### Pain Points
1. **Legacy POS Systems** — Old point-of-sale systems hindering omnichannel strategy
2. **Cloud Cost Out of Control** — Cloud spend growing faster than business metrics
3. **Inventory Optimization** — Demand forecasting poor; stockouts and overstock
4. **Customer Experience Degradation** — Losing to pure-play e-commerce competitors
5. **Competitor GenAI Adoption** — Competitors deploying AI chatbots; losing customers
6. **Store Tech Complexity** — Managing devices/systems across 50+ stores difficult

### Insight Solutions
- **Cloud Infrastructure for Omnichannel:** Modern cloud infrastructure for unified commerce
- **Cloud Cost Optimization:** FinOps framework to control spend
- **AI-Powered Customer Engagement:** GenAI chatbots for customer service
- **Inventory Optimization:** AI-driven demand forecasting
- **Device Lifecycle (In-Store):** Managing in-store technology across locations
- **Modern Workplace:** POS system modernization, employee experience

### Proof Points
- Petbarn PetAI: AI-powered personalization improving customer engagement
- Retail cloud migrations: Zero-downtime migrations of store systems
- GenAI chatbot deployments: 30%+ cost reduction in customer service

### Discovery Questions
1. "How many stores? What's your in-store technology strategy?"
2. "Are you satisfied with your e-commerce platform and omnichannel experience?"
3. "What's your cloud spend trajectory? Growing faster than business?"
4. "Are you exploring GenAI for customer engagement?"
5. "How are you competing against pure-play e-commerce?"

### Qualification Signals
✅ **Highly Qualified:** 50+ stores, significant cloud spend, VP/CMO involved, budget allocated  
⏳ **Moderately Qualified:** Exploring modernization, smaller footprint, IT-only  
🔄 **Nurture:** Considering but no immediate timeline

---

## INDUSTRY 3: MANUFACTURING & ADVANCED INDUSTRIES

### Market Context
- **Industry 4.0:** Smart factories, IoT, data-driven decision-making
- **Predictive Maintenance:** Shifting from reactive to predictive maintenance
- **Supply Chain Visibility:** End-to-end supply chain transparency becoming critical
- **Digital Twins:** Virtual factory models for optimization

### Pain Points
1. **Legacy Equipment, Poor Data Visibility** — Old machines don't generate useful data
2. **Supply Chain Disruptions** — Limited visibility into supply chain; surprised by shortages
3. **Downtime Costs** — Equipment failure = production loss = revenue loss
4. **Data Analytics Gaps** — Collecting data but can't derive insights
5. **AI for Predictive Maintenance** — Want to prevent downtime but unclear how
6. **Skills Gap** — Data science and IoT expertise limited

### Insight Solutions
- **Edge AI for Predictive Maintenance:** AI models predicting equipment failure
- **IoT Infrastructure:** Sensors and data collection from equipment
- **Supply Chain Analytics:** End-to-end visibility and optimization
- **Predictive Maintenance Models:** ML models trained on historical data
- **Cloud Data Infrastructure:** Scalable data warehouse for manufacturing data
- **Digital Twin Simulation:** Virtual factory models

### Proof Points
- Manufacturing AI: Predictive maintenance reducing downtime
- IoT deployments: Real-time equipment monitoring
- Supply chain optimization: Demand forecasting improving inventory

### Discovery Questions
1. "How old is your manufacturing equipment? Is it smart/connected?"
2. "What's your biggest operational pain—downtime, supply chain, quality?"
3. "Do you have visibility into end-to-end supply chain?"
4. "Have you explored predictive maintenance? What's preventing adoption?"
5. "Do you have data science expertise in-house?"

### Qualification Signals
✅ **Highly Qualified:** Recent downtime incident, significant cost impact, digital transformation underway  
⏳ **Moderately Qualified:** Exploring Industry 4.0, limited budget  
🔄 **Nurture:** Early-stage thinking

---

## INDUSTRY 4: FINANCIAL SERVICES

### Market Context
- **Fintech Competition:** Traditional banks losing customers to fintech (digital-native)
- **Regulatory Compliance:** Constant compliance framework changes (GDPR, MiFID II, Basel III)
- **GenAI for Customer Engagement:** Banks deploying AI advisors, chatbots
- **Fraud Detection AI:** AI increasingly used for fraud prevention

### Pain Points
1. **Customer Experience Falling Behind Fintech** — Losing millennials to digital-native competitors
2. **Regulatory Compliance Complexity** — Keeping up with changing regulations; compliance costs rising
3. **Fraud Detection Limitations** — Current systems missing sophisticated fraud
4. **GenAI Security Concerns** — Want GenAI customer engagement but worried about data security
5. **Legacy Infrastructure** — Aging systems hindering innovation
6. **Cost Pressure** — Operating costs higher than digital competitors

### Insight Solutions
- **GenAI Customer Engagement:** AI advisor chatbots (ChatGPT-like)
- **Compliance Automation:** Automate compliance monitoring and reporting
- **Fraud Detection AI:** ML models detecting sophisticated fraud
- **Cloud Modernization:** Regulated cloud infrastructure (SOC 2, FedRAMP-ready)
- **Security Hardening:** Zero-trust architecture for financial data
- **Cost Optimization:** Cloud FinOps to reduce infrastructure costs

### Proof Points
- Financial services chatbot: 30% call center cost reduction
- Fraud detection AI: Detection rates improving while false positives decreasing
- Compliance automation: Audit preparation time reduced by 50%+

### Discovery Questions
1. "How are you competing against fintech? Digital experience parity?"
2. "What's your GenAI strategy? Are you exploring AI advisors or customer bots?"
3. "What compliance frameworks apply? Recent audit findings?"
4. "Are you concerned about data security in GenAI implementations?"
5. "Where is your biggest cost pressure—operations, technology, infrastructure?"

### Qualification Signals
✅ **Highly Qualified:** Lost market share to fintech, GenAI pilot planned, Chief Digital Officer involved  
⏳ **Moderately Qualified:** Exploring GenAI, budget exploratory  
🔄 **Nurture:** Strategic interest but no immediate timeline

---

## INDUSTRY 5: GOVERNMENT (Federal, State, Local)

### Market Context
- **Digital Transformation Mandate:** Government agencies modernizing IT
- **FedRAMP Requirements:** Any cloud deployment must be FedRAMP-authorized
- **Budget Constraints:** Limited IT budgets; must justify every dollar
- **Security & Compliance:** FISMA, NIST, security requirements extremely stringent
- **Procurement Complexity:** Government procurement is slow and bureaucratic
- **Talent Retention:** Difficulty competing with private sector for tech talent

### Pain Points
1. **FedRAMP Certification Complexity** — Confusing process, many vendors not FedRAMP-ready
2. **Legacy Infrastructure Aging** — Old systems breaking down; replacement urgent
3. **Government Procurement Bureaucracy** — RFP process slow; difficult to implement quickly
4. **Security & Compliance Requirements** — FISMA, NIST requirements onerous
5. **Budget Cycle Constraints** — Fiscal year budgets; difficult to shift funds mid-year
6. **Talent Retention** — Can't compete with private sector salaries

### Insight Solutions
- **FedRAMP Cloud Modernization:** Cloud migration with FedRAMP authorization
- **Security Hardening:** FISMA/NIST-compliant security architecture
- **Government IT Modernization:** Legacy system replacement
- **GSA/SEWP/CIO-NS Procurement:** Pre-approved contracts (no competitive bidding)
- **Agency-Specific Solutions:** Federal, state, local agency expertise

### Proof Points
- 20+ government agencies modernized
- FedRAMP-authorized cloud implementations
- Emergency response infrastructure (supporting critical services)
- Telehealth deployment (rapid deployment capability)

### Discovery Questions
1. "Are you federal, state, or local government?"
2. "Is FedRAMP a requirement for your cloud migration?"
3. "What's driving your modernization—aging infrastructure, budget pressure, or security?"
4. "What's your IT budget cycle? When are you planning modernization?"
5. "Have you worked with FedRAMP-authorized vendors before?"

### Qualification Signals
✅ **Highly Qualified:** FedRAMP requirement, budget approved, CIO/VP IT involved, timeline defined  
⏳ **Moderately Qualified:** Planning modernization, budget exploratory, IPS discovery phase  
🔄 **Nurture:** Early-stage strategic planning

### ⚠️ **CRITICAL ROUTING:** Any government agency → IMMEDIATELY route to Insight Public Sector (IPS) team

---

## INDUSTRY 6: EDUCATION (K-12, Higher Education, State Education Departments)

### Market Context
- **Hybrid Learning:** Post-COVID, hybrid learning model becoming permanent
- **Digital Campus:** Student and faculty increasingly expect digital tools
- **Student Data Security:** Student records protection critical (FERPA compliance)
- **Budget Constraints:** Education funding typically tight; must justify tech spend

### Pain Points
1. **Device Management Complexity** — Managing 1,000s of devices across schools/districts difficult
2. **Hybrid Learning Infrastructure** — Need robust infrastructure for remote students
3. **Student Data Security** — FERPA compliance; protecting student privacy critical
4. **Campus IT Complexity** — Managing campus-wide IT systems (multiple buildings, departments)
5. **Limited IT Budget** — Technology budgets often inadequate; must prioritize
6. **Outdated Systems** — Many schools still running legacy systems

### Insight Solutions
- **Device Lifecycle Management:** Managing K-12 or campus device fleets
- **Cloud Backup & Disaster Recovery:** Enabling hybrid learning with cloud backup
- **Student Data Security:** FERPA-compliant security architecture
- **Unified Communications:** Teams, Zoom implementation for campus-wide collaboration
- **Modern Workplace:** Replacing legacy systems with cloud-based alternatives

### Proof Points
- Cloud backup enabling hybrid learning (post-COVID success)
- Device management at scale (1,000s of devices)
- Campus modernization (reducing IT burden)

### Discovery Questions
1. "How many students/faculty? How many devices?"
2. "Are you running hybrid learning? Infrastructure ready?"
3. "What's your biggest IT challenge—device management, data security, or aging systems?"
4. "Have you migrated to cloud backup? Disaster recovery plan?"
5. "What's your IT budget for modernization?"

### Qualification Signals
✅ **Highly Qualified:** District/university digital transformation, budget approved, IT director involved  
⏳ **Moderately Qualified:** Exploring modernization, budget exploratory, IT-only  
🔄 **Nurture:** Strategic interest, no immediate timeline

---

## INSIGHT PUBLIC SECTOR (IPS) REFERENCE

### What is IPS?

**Insight Public Sector** is a dedicated team within Insight specializing in government agency IT modernization, compliance, and solutions.

### IPS Coverage Areas
- **Federal Government** (civilian, defense)
- **State Government** (state agencies, state education departments)
- **Local Government** (city, county, municipality)
- **Healthcare** (government hospitals, VA, state health departments)
- **Education** (K-12 school districts, state universities)
- **Emergency Response** (first responders, emergency management)

### IPS Expertise
- ✅ FedRAMP certification and compliance
- ✅ FISMA (Federal Information Security Management Act) compliance
- ✅ Government procurement (GSA, SEWP V, CIO-NS contracts)
- ✅ Budget cycles and political navigation
- ✅ Security clearances and vetting
- ✅ Government-specific solutions and best practices

### IPS Procurement Contracts
- **GSA (General Services Administration):** Federal agencies can order directly
- **SEWP V (Solutions for Enterprise-Wide Procurement):** Federal agencies, no competitive bidding
- **CIO-NS (Chief Information Officer - National Security):** Federal agencies (CIO council)

### When to Route to IPS

**ROUTE TO IPS IMMEDIATELY IF:**
- ✅ Prospect is federal government agency
- ✅ Prospect is state government agency
- ✅ Prospect is local government (city, county)
- ✅ Prospect is healthcare provider with government contracts (VA, state hospital)
- ✅ Prospect mentions FedRAMP, FISMA, GSA, SEWP

**Script for IPS Routing:**
"Based on what you've shared, you're in the public sector, which is an area of deep expertise for our dedicated IPS team. They understand FedRAMP, procurement frameworks, and government compliance better than I can. Let me connect you with an IPS specialist who can dive deeper into your specific requirements."

### IPS Contact Model
- Prospect starts with X-Agent SDR
- X-Agent qualifies and identifies government agency need
- X-Agent routes to IPS team
- IPS specialist takes over (handles technical, compliance, procurement questions)

---

## INDUSTRY SELECTION FRAMEWORK

**When choosing which industry to focus in outreach:**

| Industry | TAM Size | Insight Strength | Growth Rate | Competition |
|----------|----------|-----------------|-------------|------------|
| Healthcare | Large | Medium-High | High | Medium |
| Retail | Large | High | Medium | High |
| Manufacturing | Large | Medium | Medium | Low |
| Finance | Large | Medium-High | Medium | High |
| Government | Medium | Very High (IPS) | High | Low |
| Education | Medium | Medium | Low | Medium |

**Recommendation:** Start with industries where Insight has strongest positioning and least competition (Government via IPS, Healthcare, Retail).

---

**Effective Date:** January 27, 2026  
**Version:** 1.0 (Production Ready)
