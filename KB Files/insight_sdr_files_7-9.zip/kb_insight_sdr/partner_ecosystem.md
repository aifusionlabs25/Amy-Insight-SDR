# Insight SDR: Partner Ecosystem Reference

## PURPOSE
Document Insight's strategic partnerships with technology vendors, cloud platforms, and service providers.

---

## CLOUD PLATFORM PARTNERS

### MICROSOFT AZURE
**Partnership Level:** Strategic Partner (18 specializations, all 4 security certifications)  
**Key Recognition:** 2023 Worldwide Solution Assessments Partner of the Year

**Why Partner with Microsoft:**
- Enterprise-focused (Office 365, Teams, Dynamics, Power Platform)
- Strong security and compliance (SOC 2, FedRAMP, HIPAA)
- Growing AI capabilities (Copilot, Azure OpenAI)
- Familiar to most enterprises (Office, Windows dominant)

**Insight Positioning:**
"We're a Microsoft Partner of the Year. We have deep expertise in Azure, Teams, Office 365, and Dynamics implementations. We can help you maximize your Microsoft investment."

**When to Position Azure:**
- Customer has Office 365 or Microsoft licensing
- Enterprise customer with Windows-first environment
- Compliance-sensitive (government, healthcare)
- AI/GenAI interest (Azure OpenAI integration)

---

### AMAZON WEB SERVICES (AWS)
**Partnership Level:** Premier Consulting Partner, Security Competency

**Why Partner with AWS:**
- Market leader in cloud infrastructure
- Strongest in data and analytics (S3, Redshift, SageMaker)
- Dominant in startup/tech companies
- Cost-competitive for certain workloads

**Insight Positioning:**
"We're an AWS Premier Partner with security expertise. We can help you optimize AWS costs and harden AWS security."

**When to Position AWS:**
- Customer already using AWS (cost optimization opportunity)
- Data/analytics intensive workload
- Startup or tech company environment
- Cost-sensitive customer (AWS often cheaper for certain workloads)

---

### GOOGLE CLOUD
**Partnership Level:** Premier Partner

**Why Partner with Google:**
- Strong in data and analytics (BigQuery, Dataflow)
- Competitive pricing for data-intensive workloads
- Growing AI capabilities (Vertex AI, Gemini)
- Attractive to data-driven companies

**Insight Positioning:**
"We're a Google Cloud Premier Partner with expertise in data analytics and AI. We can help you build data-driven capabilities on Google Cloud."

**When to Position Google Cloud:**
- Data/analytics intensive
- AI/ML use cases
- Cost optimization opportunity
- Customer interested in Google services

---

### MULTI-CLOUD POSITIONING (CRITICAL)

**How to Position Partnerships:**
"We work with AWS, Azure, and Google Cloud. We don't have a preferred vendor—we recommend what's best for YOUR workloads. Some customers run across all three."

**Why Multi-Cloud Matters:**
- Avoid vendor lock-in
- Optimize each workload to best-fit platform
- Gives customer negotiating leverage with vendors
- Reflects market reality (many enterprises are multi-cloud)

**Messaging:**
"We're not pushing any single cloud. We architect multi-cloud strategies based on each workload's requirements. That gives you flexibility and control."

---

## NETWORKING & SECURITY PARTNERS

### CISCO
**Partnership:** 2024 Cisco Americas Enterprise Partner of the Year

**Products/Services:**
- Networking (switches, routers, firewalls, security appliances)
- Collaboration (Webex video conferencing)
- Security (threat detection, endpoint security)

**When to Reference:**
- Customer interested in Cisco networking or security
- Collaboration infrastructure (Teams vs. Webex decision)
- Security hardening

---

### SYMANTEC
**Partnership:** Backup and data protection

**Products/Services:**
- Backup and recovery solutions
- Data protection and encryption
- Endpoint protection

**When to Reference:**
- Backup and disaster recovery discussions
- Data protection requirements
- Endpoint security needs

---

### VEEAM
**Partnership:** Backup, recovery, and data availability

**Products/Services:**
- Backup and recovery (on-premises and cloud)
- Ransomware protection
- Disaster recovery

**When to Reference:**
- Backup and disaster recovery needs
- Ransomware protection discussion
- Business continuity requirements

---

### CROWDSTRIKE
**Partnership:** Endpoint detection and response (EDR)

**Products/Services:**
- Endpoint detection and response
- Threat intelligence
- Managed threat hunting

**When to Reference:**
- Endpoint security hardening
- Threat detection discussion
- 24/7 security monitoring

---

## DATA & AI PARTNERS

### OPENAI (ChatGPT)
**Partnership:** Integration with Azure OpenAI Service

**Why Important:**
- ChatGPT is de facto generative AI standard
- Azure OpenAI provides enterprise-safe option
- Insight helps customers implement ChatGPT-like solutions safely

**When to Reference:**
- Customer asking about ChatGPT
- GenAI customer engagement (chatbots)
- Content generation use cases
- Enterprise AI safety concerns

**Positioning:**
"ChatGPT is powerful but has data security concerns for enterprises. We help you implement ChatGPT-like capabilities safely using Azure OpenAI, which keeps your data on your infrastructure."

---

### GOOGLE VERTEX AI
**Partnership:** Managed ML platform on Google Cloud

**Why Important:**
- Competes with Azure ML and AWS SageMaker
- Strong for data-intensive ML
- Includes Gemini (Google's GenAI model)

**When to Reference:**
- Customer on Google Cloud
- Data analytics and ML use cases
- GenAI implementations on Google

---

### DATABRICKS
**Partnership:** Data analytics and ML platform

**Why Important:**
- Unified data analytics platform
- Works across AWS, Azure, Google Cloud
- Strong for data engineering and ML

**When to Reference:**
- Customer building data lake/warehouse
- ML model development needs
- Data engineering complexity

---

### HUGGING FACE
**Partnership:** Open-source AI models

**Why Important:**
- Community of AI models available
- Open-source alternative to proprietary GenAI
- Strong for specialized models

**When to Reference:**
- Customer interested in open-source AI
- Customized GenAI models
- AI model fine-tuning discussions

---

## MODERN WORKPLACE PARTNERS

### MICROSOFT
**Partnership:** Microsoft Partner of the Year 2023

**Products/Services:**
- Office 365 (Teams, Outlook, SharePoint, OneDrive)
- Windows and Enterprise Mobility Management
- Dynamics 365 (CRM, ERP)
- Power Platform (Power Apps, Power Automate, Power BI)
- Copilot (AI assistants across Microsoft products)

**When to Reference:**
- Office 365 migration
- Modern workplace modernization
- AI-powered productivity (Copilot)
- Unified workplace strategy

---

### APPLE
**Partnership:** Apple technology deployment and support

**Products/Services:**
- Mac devices and iOS support
- Apple ecosystem for enterprise

**When to Reference:**
- Customer with Apple devices
- BYOD (bring your own device) environment
- Executive Mac/iPad deployments

**Proof Point:** Government agency telehealth deployment with 1,000+ Apple devices (rapid deployment capability)

---

### HP / LENOVO
**Partnership:** Device procurement and lifecycle management

**Products/Services:**
- Laptops, desktops, workstations
- Device fleet management
- Hardware as a service options

**When to Reference:**
- Device procurement discussions
- Device lifecycle management
- Hardware refresh cycles

---

### ZOOM
**Partnership:** Video conferencing and unified communications

**Products/Services:**
- Video conferencing
- Webinars
- Unified communications

**When to Reference:**
- Video conferencing platform selection
- Unified communications strategy
- Webinar/large meeting infrastructure

---

### CISCO WEBEX
**Partnership:** Video conferencing (Cisco)

**Products/Services:**
- Video conferencing and collaboration
- Meetings and webinars
- Unified communications

**When to Reference:**
- Customer using Cisco infrastructure
- Video conferencing modernization
- Unified communications strategy

---

## IDENTITY & ACCESS MANAGEMENT (IAM) PARTNERS

### OKTA
**Partnership:** Identity management platform

**Why Important:**
- Market leader in identity management
- Cloud-native approach
- Works with any application

**When to Reference:**
- IAM modernization discussion
- Single sign-on (SSO) implementation
- Identity governance

---

### PING IDENTITY
**Partnership:** Identity management and API security

**Why Important:**
- Strong in healthcare and financial services
- API security focus
- Cloud and on-premises options

**When to Reference:**
- Healthcare or financial services IAM
- API security requirements
- Identity governance complexity

---

### CYBERARK
**Partnership:** Privileged access management (PAM)

**Why Important:**
- Market leader in PAM
- Prevents insider threats
- Zero-trust component

**When to Reference:**
- Privileged account security
- Zero-trust architecture
- Insider threat prevention

---

## BACKUP & DISASTER RECOVERY PARTNERS

### COMMVAULT
**Partnership:** Backup, recovery, and data management

**Why Important:**
- Works across cloud and on-premises
- Comprehensive data protection
- Disaster recovery capabilities

**When to Reference:**
- Backup and disaster recovery needs
- Data management requirements
- Multi-cloud backup strategy

---

## PUBLIC SECTOR PROCUREMENT PARTNERS

### GSA (General Services Administration)
**What:** Federal procurement vehicle for civilian agencies

**How It Works:**
- Insight has GSA contract
- Federal agencies can order directly from Insight
- No competitive bidding required (faster procurement)

**When to Reference:** Federal agency prospect
**Positioning:** "We're on GSA contract, so your procurement process is simplified—no RFP needed."

---

### SEWP V (Solutions for Enterprise-Wide Procurement)
**What:** Government contract vehicle for multiple agencies

**How It Works:**
- Insight approved on SEWP V
- Federal agencies can order directly
- No competitive bidding required

**When to Reference:** Federal agency prospect
**Positioning:** "We're on SEWP V, which means you can issue a task order without competitive bidding—faster timeline."

---

### CIO-NS (Chief Information Officer - National Security)
**What:** Specialized government contract vehicle

**How It Works:**
- For agencies with security requirements
- Vetted and approved vendors
- Streamlined procurement

**When to Reference:** Federal agency with security requirements
**Positioning:** "We're on CIO-NS, which streamlines your procurement and ensures security requirements are met."

---

## HOW TO POSITION PARTNERSHIPS (Key Messaging)

### ✅ Partnerships Enable Unbiased Recommendations
"Our partnerships with Microsoft, AWS, and Google Cloud give us access to resources and expertise. But we remain unbiased. We recommend what's right for you, not what we prefer."

### ✅ Partnerships Don't Create Lock-In
"We're not tied to any single vendor. We work with all the major platforms, which means we can architect multi-cloud strategies that work for you."

### ✅ Partnerships Provide Value
"Our partnerships give us early access to new features, special pricing for customers, and deep technical resources. That translates to better solutions and lower costs for you."

### ✅ Partnerships Ensure Coverage
"We work with the best-of-breed vendors. If you need something specific, we have partnerships to support it. And if not, we can bring in the right specialist."

---

**Effective Date:** January 27, 2026  
**Version:** 1.0 (Production Ready)
